/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "0511413e338a34d65ca37b3aeecf9d29"
  }, {
    "url": "pwa-512x512.png",
    "revision": "0511413e338a34d65ca37b3aeecf9d29"
  }, {
    "url": "pwa-192x192.png",
    "revision": "ef3154de208fb7780962359964507796"
  }, {
    "url": "profil.html",
    "revision": "df9c0990c522a6c47b77ac5a2e7e3472"
  }, {
    "url": "logo-kafelaslaundry.png",
    "revision": "3653e10daf02458fd706e3ba79d3d496"
  }, {
    "url": "logo-kafela.svg",
    "revision": "ab67121f0ce12936ba759181297bdbd1"
  }, {
    "url": "logo-kafela.png",
    "revision": "0511413e338a34d65ca37b3aeecf9d29"
  }, {
    "url": "logo kafelas laundry.png",
    "revision": "a820077156732a90366b57b400a434be"
  }, {
    "url": "index.html",
    "revision": "9266c27bbcae60d381a7da1b02179d76"
  }, {
    "url": "icon.svg",
    "revision": "ab67121f0ce12936ba759181297bdbd1"
  }, {
    "url": "firebase-config.js",
    "revision": "7196c263dd49218b7c314223d2ee2eea"
  }, {
    "url": "favicon.svg",
    "revision": "ab67121f0ce12936ba759181297bdbd1"
  }, {
    "url": "favicon.ico",
    "revision": "a4f0b906c4a2fa9b7be9ad93ae8d2d4c"
  }, {
    "url": "booking.html",
    "revision": "3f493f16c94292e5cf0d128c7d2767c7"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "ef3154de208fb7780962359964507796"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-BSXAu9-m.js",
    "revision": null
  }, {
    "url": "assets/index-B5aBxj7o.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "ef3154de208fb7780962359964507796"
  }, {
    "url": "favicon.ico",
    "revision": "a4f0b906c4a2fa9b7be9ad93ae8d2d4c"
  }, {
    "url": "icon.svg",
    "revision": "ab67121f0ce12936ba759181297bdbd1"
  }, {
    "url": "pwa-192x192.png",
    "revision": "ef3154de208fb7780962359964507796"
  }, {
    "url": "pwa-512x512.png",
    "revision": "0511413e338a34d65ca37b3aeecf9d29"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "0511413e338a34d65ca37b3aeecf9d29"
  }, {
    "url": "manifest.webmanifest",
    "revision": "2c3a4f65f2f856757669840a5f30b6e4"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
